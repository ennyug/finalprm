package fukie.sieunhanhav.task;

import android.os.AsyncTask;

/**
 * Created by Fukie on 19/03/2016.
 */
public class IniAsyncTask extends AsyncTask<Void, Void, Void> {
    public static boolean isRunning;

    @Override
    protected void onPostExecute(Void result) {
    }

    @Override
    protected Void doInBackground(Void... params) {
        return null;
    }
}
